#include "hash.h"

hash::hash()
{

}

QString hash::create(QString str)
{

     QString::fromUtf8(const QByteArray &str)
     QCryptographicHash::hash(str.ToByteArray(), QCryptographicHash::Sha256).toHex();
}
