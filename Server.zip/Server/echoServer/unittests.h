#ifndef UNITTESTS_H
#define UNITTESTS_H


struct Unit_Tests
{
public:
    Unit_Tests();
    static bool Test1();
};
#endif // UNITTESTS_H
