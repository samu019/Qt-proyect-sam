#include "vigenere.h"

vigenere::vigenere()
{

}
